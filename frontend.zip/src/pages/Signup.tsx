  import { useState } from "react";
  import axios from "axios";
  import { useNavigate } from "react-router-dom";

  export default function Signup() {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [error, setError] = useState("");

    const navigate = useNavigate();

    const handleSignup = async () => {
      try {
        setError(""); // reset previous error

        const res = await axios.post("http://localhost:5000/Auth/signup", { // match backend exactly
          name,
          email,
          password
        });

        alert(res.data.message);
        navigate("/Home");
      } catch (err: any) {
        console.error(err);

        // Display backend error message
        if (err.response && err.response.data && err.response.data.error) {
          setError(err.response.data.error);
        } else {
          setError("Signup failed. Please try again.");
        }
      }
    };

    return (
      <div className=" d-flex justify-content-center align-items-center vh-100 bg-dark">
        <div className="card p-4 shadow" style={{ width: "350px" }}>
          <h4 className="text-center mb-3 display-6">Signup</h4>

          {error && <div className="alert alert-danger">{error}</div>}

          <input 
            className="form-control mb-2"
            placeholder="Name"
            value={name}
            onChange={e => setName(e.target.value)}
          />

          <input 
            className="form-control mb-2"
            placeholder="Email"
            value={email}
            onChange={e => setEmail(e.target.value)}
          />

          <input 
            type="password"
            className="form-control mb-3"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
          />

          <button className="btn btn-dark w-100" onClick={handleSignup}>
            Signup
          </button>

          <p className="text-center mt-3">
            Already have an account? <a href="/" className="text-decoration-none">Login</a>
          </p>
        </div>
      </div>
    );
  }
