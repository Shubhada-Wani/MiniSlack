import Sidebar from "../components/Sidebar";
import ChatWindow from "../components/ChatWindow";
import { useState } from "react";

export default function Home() {
  const [channelId, setChannelId] = useState("");

  return (
    <div className="d-flex" style={{ height: "100vh" }}>
      <Sidebar setChannelId={setChannelId} activeChannelId={""} />
      <ChatWindow channelId={channelId} />
    </div>
  );
}
