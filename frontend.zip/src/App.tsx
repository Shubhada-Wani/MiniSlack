import './App.css'
import '../node_modules/bootstrap/dist/css/bootstrap.min.css'
import '../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Login from './pages/Login.js'
import Signup from './pages/Signup.js'
import Home from './pages/Home.js'

function App() {
  
  return (
    <>
      <BrowserRouter>
      <Routes>
        <Route path='/' element = {<Login/>}/>
        <Route path='/Signup' element= {<Signup/>}/>
        <Route path='/Home' element = {<Home/>}/>
      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
