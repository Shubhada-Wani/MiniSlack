import { useEffect, useState, useRef } from "react";
import axios from "axios";

type Props = {
  channelId: string;
};

export default function ChatWindow({ channelId }: Props) {
  const [messages, setMessages] = useState<any[]>([]);
  const [text, setText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const user = JSON.parse(localStorage.getItem("user") || "{}");

  // Load messages from backend
const loadMessages = () => {
  if (!channelId) return; // channel not selected yet
  axios.get(`http://localhost:5000/message/${channelId}`)
    .then(res => setMessages(res.data))
    .catch(err => console.error("Failed to load messages:", err));
};

  // Auto-scroll to latest message
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Load messages initially and whenever channelId changes
  useEffect(() => {
    loadMessages();
  }, [channelId]);

  // Scroll whenever messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Optional: poll for new messages every 3 seconds
  useEffect(() => {
    const interval = setInterval(loadMessages, 3000);
    return () => clearInterval(interval);
  }, [channelId]);

  // Send a new message
  const sendMessage = async () => {
    if (!text.trim()) return; // Prevent empty messages
    try {
      const res = await axios.post("http://localhost:5000/message", {
        channelId,
        user: user.name,
        text,
      });
      setMessages(prev => [...prev, res.data]); // Add message immediately
      setText("");
    } catch (err) {
      console.error("Failed to send message:", err);
    }
  };

  return (
    <div className="flex-grow-1 p-3 d-flex flex-column" style={{ height: "100%" }}>
      <h4 className="display-6">Chat :) </h4>

      <div 
        className="border p-2 mb-3 flex-grow-1"
        style={{ overflowY: "auto" }}
      >
        {messages.map((msg: any) => (
          <div key={msg._id} className="mb-2 ">
            <strong>{msg.user}</strong>: {msg.text}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="d-flex">
        <input
          className="form-control"
          placeholder="Type message..."
          value={text}
          onChange={e => setText(e.target.value)}
          onKeyDown={e => e.key === "Enter" && sendMessage()}
        />
        <button className="btn btn-dark rounded-pill ms-2" onClick={sendMessage}>
          Send
        </button>
      </div>
    </div>
  );
}
