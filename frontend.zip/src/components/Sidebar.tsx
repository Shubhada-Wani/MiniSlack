import { useEffect, useState } from "react";
import axios from "axios";
import '../App.css'

type Props = {
  setChannelId: (id: string) => void;
  activeChannelId: string;
};

export default function Sidebar({ setChannelId }: Props) {
  const [channels, setChannels] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/channel")
      .then(res => setChannels(res.data));
  }, []);

  return (
    <div className="bg-dark text-white p-md-3 py-3 px-1 sidebar " >
      <h5 className="display-6 text-wrap">Channels</h5>
      <ul className="list-unstyled mt-3  ">
        {channels.map((ch: any) => (
          <li className="text-light" 
            key={ch._id}
            onClick={() => setChannelId(ch._id)}
            style={{ cursor: "pointer", padding: "8px 0" }}
          >
            # {ch.name}
          </li>
        ))}
      </ul>
    </div>
  );
}
