const express = require("express");
const Channel = require("../models/Channel");
const router = express.Router();

// Get channels
router.get("/", async (req, res) => {
  const channels = await Channel.find();
  res.json(channels);
});

// Create channel
router.post("/", async (req, res) => {
  const channel = new Channel({ name: req.body.name });
  await channel.save();
  res.json(channel);
});

module.exports = router;
