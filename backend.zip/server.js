
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/minislack")
  .then(() => console.log("Mongo DB Connected"))
  .catch(err => console.log(err));

app.get("/", (req, res) => {
  res.send("Mini Slack Backend Running");
});

app.listen(5000, () => console.log("Server running on 5000"));

app.use("/Auth", require("./routes/Auth"));
app.use("/channel", require("./routes/channel"));
app.use("/message", require("./routes/message"));

